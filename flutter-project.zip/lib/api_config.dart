const String baseUrl = "http://panelnyariostore.keselekbijiwowo.web.id:4995"; 
const String wsUrl = "wss://panelnyariostore.keselekbijiwowo.web.id:4995";