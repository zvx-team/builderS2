import 'dart:convert';
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';
import 'api_config.dart';

const Color navyDeep = Color(0xFF0A1929);
const Color navyMedium = Color(0xFF1E2F4A);
const Color navyLight = Color(0xFF2A3F5F);
const Color navyBlue = Color(0xFF1E3A8A);
const Color skyBlue = Color(0xFF2D7FF9);
const Color skyLight = Color(0xFF4A9EFF);
const Color skyGlow = Color(0xFF7FB2F0);
const Color cyanTech = Color(0xFF00C8FF);
const Color textPrimary = Colors.white;
const Color textSecondary = Color(0xFFB0B8C5);
const Color successGreen = Color(0xFF10B981);
const Color errorRed = Color(0xFFEF4444);
const Color warningOrange = Color(0xFFF59E0B);

class TestFunctionPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;

  const TestFunctionPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<TestFunctionPage> createState() => _TestFunctionPageState();
}

class _TestFunctionPageState extends State<TestFunctionPage> with TickerProviderStateMixin {
  // ========== CONTROLLERS ==========
  final TextEditingController _codeController = TextEditingController();
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _jumlahController = TextEditingController(text: '1');
  final TextEditingController _sleepController = TextEditingController(text: '1000');
  
  // ========== STATE VARIABLES ==========
  String _selectedFunction = '';
  List<String> _extractedFunctions = [];
  List<Map<String, dynamic>> _senders = [];
  String? _selectedSenderId;
  bool _isLoadingSenders = false;
  bool _isValidating = false;
  bool _isExecuting = false;
  String? _validationResult;
  Map<String, dynamic>? _validationError;
  String? _executionId;
  Map<String, dynamic>? _executionResult;
  Timer? _pollingTimer;
  
  // ========== ANIMATION CONTROLLERS ==========
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _pulseController;
  late AnimationController _particleController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _fetchSenders();
    
    // Set default code contoh
    _codeController.text = '''
// Contoh function test
async function test(target) {
  console.log("Mengirim ke:", target);
  return "OK";
}

// Function dengan sendMessage
async function sendMessageTest(target) {
  await sendMessage(target, { text: "Hello from test function!" });
  console.log("Message sent");
}

// Function dengan relayMessage
async function relayMessageTest(target) {
  const message = { conversation: "Hello via relayMessage" };
  await relayMessage(target, message);
  console.log("Message relayed");
}
''';
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = CurvedAnimation(parent: _fadeController, curve: Curves.easeIn);
    
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));
    
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    
    _particleController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();
    
    _fadeController.forward();
    _slideController.forward();
  }

  // ========== FETCH SENDERS ==========
  Future<void> _fetchSenders() async {
    setState(() => _isLoadingSenders = true);
    
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/testfunction/senders?key=${widget.sessionKey}'),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _senders = List<Map<String, dynamic>>.from(data['connections']['private'] ?? []);
          });
        }
      }
    } catch (e) {
      debugPrint('Error fetching senders: $e');
    } finally {
      setState(() => _isLoadingSenders = false);
    }
  }

  Future<void> _validateCode() async {
    if (_codeController.text.trim().isEmpty) {
      _showSnackBar('Code is empty', isError: true);
      return;
    }
    
    setState(() {
      _isValidating = true;
      _validationResult = null;
      _validationError = null;
    });
    
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/testfunction/validatee'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'code': _codeController.text,
        }),
      );
      
      final data = jsonDecode(response.body);
      
      if (data['valid'] == true) {
        setState(() {
          _validationResult = '✅ Syntax valid!';
          _validationError = null;
        });
        
        // Extract functions setelah validasi sukses
        _extractFunctions();
      } else {
        setState(() {
          _validationResult = null;
          _validationError = data['error'];
        });
      }
    } catch (e) {
      setState(() {
        _validationError = {'message': 'Connection error: $e'};
      });
    } finally {
      setState(() => _isValidating = false);
    }
  }

  // ========== EXTRACT FUNCTIONS ==========
  Future<void> _extractFunctions() async {
    if (_codeController.text.trim().isEmpty) return;
    
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/testfunction/extract'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'code': _codeController.text,
        }),
      );
      
      final data = jsonDecode(response.body);
      
      setState(() {
        _extractedFunctions = List<String>.from(data['functions'] ?? []);
        if (_extractedFunctions.isNotEmpty && _selectedFunction.isEmpty) {
          _selectedFunction = _extractedFunctions.first;
        }
      });
    } catch (e) {
      debugPrint('Error extracting functions: $e');
    }
  }

  // ========== EXECUTE FUNCTION ==========
  Future<void> _executeFunction() async {
    if (_codeController.text.trim().isEmpty) {
      _showSnackBar('Code is empty', isError: true);
      return;
    }
    
    if (_selectedFunction.isEmpty) {
      _showSnackBar('Please select a function', isError: true);
      return;
    }
    
    if (_targetController.text.trim().isEmpty) {
      _showSnackBar('Target is required', isError: true);
      return;
    }
    
    if (_selectedSenderId == null) {
      _showSnackBar('Please select a sender', isError: true);
      return;
    }
    
    final jumlah = int.tryParse(_jumlahController.text) ?? 1;
    if (jumlah < 1 || jumlah > 1000) {
      _showSnackBar('Jumlah must be between 1-1000', isError: true);
      return;
    }
    
    final sleepMs = int.tryParse(_sleepController.text) ?? 1000;
    if (sleepMs < 100 || sleepMs > 60000) {
      _showSnackBar('Sleep must be between 100-60000 ms', isError: true);
      return;
    }
    
    setState(() {
      _isExecuting = true;
      _executionResult = null;
    });
    
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/testfunction/execute'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'code': _codeController.text,
          'functionName': _selectedFunction,
          'target': _targetController.text.trim(),
          'jumlah': jumlah,
          'sleepMs': sleepMs,
          'senderId': _selectedSenderId,
        }),
      );
      
      final data = jsonDecode(response.body);
      
      if (data['success'] == true) {
        setState(() {
          _executionId = data['executionId'];
        });
        
        _showSnackBar('✅ Execution started!');
        
        _startPollingResult(data['executionId']);
      } else {
        setState(() {
          _executionResult = {
            'success': false,
            'error': data['error']
          };
          _isExecuting = false;
        });
      }
    } catch (e) {
      setState(() {
        _executionResult = {
          'success': false,
          'error': {'message': 'Connection error: $e'}
        };
        _isExecuting = false;
      });
    }
  }

  // ========== POLLING RESULT ==========
  void _startPollingResult(String executionId) {
    _pollingTimer?.cancel();
    
    _pollingTimer = Timer.periodic(const Duration(seconds: 2), (timer) async {
      try {
        final response = await http.get(
          Uri.parse('$baseUrl/api/testfunction/result/$executionId'),
        );
        
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          
          if (data['found'] == true) {
            setState(() {
              _executionResult = data;
              _isExecuting = false;
            });
            timer.cancel();
          }
        }
      } catch (e) {
        debugPrint('Error polling result: $e');
      }
      
      if (timer.tick >= 60) {
        timer.cancel();
        setState(() {
          _isExecuting = false;
          _showSnackBar('Execution timeout', isError: true);
        });
      }
    });
  }

  // ========== PICK FILE ==========
  Future<void> _pickFile() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['js'],
      );
      
      if (result != null) {
        final file = result.files.first;
        if (file.bytes != null) {
          setState(() {
            _codeController.text = utf8.decode(file.bytes!);
          });
          _showSnackBar('✅ File loaded: ${file.name}');
          _validateCode();
        }
      }
    } catch (e) {
      _showSnackBar('Error picking file: $e', isError: true);
    }
  }

  // ========== CLEAR CODE ==========
  void _clearCode() {
    setState(() {
      _codeController.clear();
      _extractedFunctions = [];
      _selectedFunction = '';
      _validationResult = null;
      _validationError = null;
    });
  }

  // ========== SHOW SNACKBAR ==========
  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(isError ? Icons.error : Icons.check_circle, color: Colors.white, size: 20),
            const SizedBox(width: 12),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: isError ? errorRed : successGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: navyDeep,
      body: Stack(
        children: [
          _buildTechBackground(),
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: Column(
                  children: [
                    _buildHeader(),
                    Expanded(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            _buildCodeEditor(),
                            const SizedBox(height: 20),
                            _buildFunctionSelection(),
                            const SizedBox(height: 20),
                            _buildTargetSection(),
                            const SizedBox(height: 20),
                            _buildSenderSelection(),
                            const SizedBox(height: 20),
                            _buildExecuteButton(),
                            const SizedBox(height: 20),
                            if (_executionResult != null || _validationError != null)
                              _buildResults(),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTechBackground() {
    return Stack(
      children: [
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [navyDeep, navyMedium, navyLight],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        CustomPaint(
          painter: GridPainter(color: skyBlue.withOpacity(0.03)),
          size: Size.infinite,
        ),
        ...List.generate(20, (index) {
          final random = math.Random(index);
          final size = (index % 3 + 1) * 2.0;
          final startX = random.nextDouble() * (MediaQuery.of(context).size.width + 200) - 100;
          final startY = random.nextDouble() * MediaQuery.of(context).size.height;
          
          return AnimatedBuilder(
            animation: _particleController,
            builder: (context, child) {
              return Positioned(
                left: startX + math.sin(_particleController.value * 2 * math.pi + index) * 20,
                top: startY + math.cos(_particleController.value * 2 * math.pi + index) * 20,
                child: Container(
                  width: size,
                  height: size,
                  decoration: BoxDecoration(
                    color: skyBlue.withOpacity(0.1 * (0.5 + 0.5 * math.sin(_particleController.value * 2 * math.pi + index))),
                    shape: BoxShape.circle,
                  ),
                ),
              );
            },
          );
        }),
      ],
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: skyBlue.withOpacity(0.2), width: 1),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [navyBlue, skyBlue],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(FontAwesomeIcons.code, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'TEST FUNCTION',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Execute custom JavaScript functions',
                  style: TextStyle(
                    color: skyBlue.withOpacity(0.7),
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: navyBlue.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: skyBlue.withOpacity(0.3)),
            ),
            child: Text(
              widget.role.toUpperCase(),
              style: TextStyle(
                color: skyBlue,
                fontSize: 11,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCodeEditor() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [navyMedium, navyLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: skyBlue.withOpacity(0.3), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(color: skyBlue.withOpacity(0.2)),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: navyBlue.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.code, color: Colors.white, size: 16),
                ),
                const SizedBox(width: 10),
                const Text(
                  'JAVASCRIPT CODE',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                  ),
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.upload_file, color: Colors.white70, size: 20),
                  onPressed: _pickFile,
                  tooltip: 'Upload .js file',
                ),
                IconButton(
                  icon: const Icon(Icons.clear, color: Colors.white70, size: 20),
                  onPressed: _clearCode,
                  tooltip: 'Clear code',
                ),
                Container(
                  margin: const EdgeInsets.only(left: 8),
                  child: ElevatedButton.icon(
                    onPressed: _isValidating ? null : _validateCode,
                    icon: _isValidating
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                        : const Icon(Icons.check_circle, size: 16),
                    label: Text(_isValidating ? 'Validating...' : 'Validate'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: skyBlue,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      textStyle: const TextStyle(fontSize: 12, fontFamily: 'ShareTechMono'),
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          Container(
            height: 200,
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _codeController,
              maxLines: null,
              expands: true,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontFamily: 'Monospace',
              ),
              decoration: InputDecoration(
                hintText: '// Write your JavaScript function here...',
                hintStyle: TextStyle(color: textSecondary.withOpacity(0.3)),
                border: InputBorder.none,
              ),
              onChanged: (value) {
                if (_validationResult != null || _validationError != null) {
                  setState(() {
                    _validationResult = null;
                    _validationError = null;
                  });
                }
              },
            ),
          ),
          
          if (_validationResult != null || _validationError != null)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: (_validationError != null ? errorRed : successGreen).withOpacity(0.1),
                border: Border(
                  top: BorderSide(color: (_validationError != null ? errorRed : successGreen).withOpacity(0.3)),
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    _validationError != null ? Icons.error : Icons.check_circle,
                    color: _validationError != null ? errorRed : successGreen,
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (_validationResult != null)
                          Text(
                            _validationResult!,
                            style: TextStyle(color: successGreen, fontSize: 12),
                          ),
                        if (_validationError != null) ...[
                          Text(
                            _validationError!['message'] ?? 'Syntax error',
                            style: TextStyle(color: errorRed, fontSize: 12),
                          ),
                          if (_validationError!['line'] != null)
                            Text(
                              'Line: ${_validationError!['line']}',
                              style: TextStyle(color: errorRed.withOpacity(0.7), fontSize: 11),
                            ),
                          if (_validationError!['snippet'] != null)
                            Container(
                              margin: const EdgeInsets.only(top: 8),
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: navyDeep,
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: errorRed.withOpacity(0.3)),
                              ),
                              child: Text(
                                _validationError!['snippet'],
                                style: TextStyle(color: errorRed.withOpacity(0.9), fontSize: 11, fontFamily: 'Monospace'),
                              ),
                            ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildFunctionSelection() {
    if (_extractedFunctions.isEmpty) {
      return const SizedBox.shrink();
    }
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [navyMedium, navyLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: skyBlue.withOpacity(0.3), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: navyBlue.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.functions, color: Colors.white, size: 16),
              ),
              const SizedBox(width: 10),
              const Text(
                'SELECT FUNCTION',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _extractedFunctions.map((func) {
              final isSelected = _selectedFunction == func;
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedFunction = func;
                  });
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: isSelected
                        ? LinearGradient(colors: [navyBlue, skyBlue], begin: Alignment.topLeft, end: Alignment.bottomRight)
                        : null,
                    color: isSelected ? null : navyDeep,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? skyBlue : skyBlue.withOpacity(0.3),
                      width: isSelected ? 1 : 1,
                    ),
                  ),
                  child: Text(
                    func,
                    style: TextStyle(
                      color: isSelected ? Colors.white : textSecondary,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildTargetSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [navyMedium, navyLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: skyBlue.withOpacity(0.3), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: navyBlue.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.my_location, color: Colors.white, size: 16),
              ),
              const SizedBox(width: 10),
              const Text(
                'TARGET & PARAMETERS',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          Container(
            decoration: BoxDecoration(
              color: navyDeep.withOpacity(0.5),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: skyBlue.withOpacity(0.3)),
            ),
            child: TextField(
              controller: _targetController,
              style: const TextStyle(color: Colors.white, fontSize: 14),
              cursorColor: skyBlue,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                hintText: '628123456789',
                hintStyle: TextStyle(color: textSecondary.withOpacity(0.3)),
                prefixIcon: Container(
                  padding: const EdgeInsets.all(14),
                  child: Icon(Icons.phone, color: skyBlue, size: 18),
                ),
                border: InputBorder.none,
              ),
            ),
          ),
          
          const SizedBox(height: 12),
          
          Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: navyDeep.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: skyBlue.withOpacity(0.3)),
                  ),
                  child: TextField(
                    controller: _jumlahController,
                    style: const TextStyle(color: Colors.white, fontSize: 14),
                    cursorColor: skyBlue,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      hintText: 'Jumlah',
                      hintStyle: TextStyle(color: textSecondary.withOpacity(0.3)),
                      prefixIcon: Container(
                        padding: const EdgeInsets.all(14),
                        child: const Icon(Icons.repeat, color: skyBlue, size: 18),
                      ),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ),
              
              const SizedBox(width: 12),
              
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: navyDeep.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: skyBlue.withOpacity(0.3)),
                  ),
                  child: TextField(
                    controller: _sleepController,
                    style: const TextStyle(color: Colors.white, fontSize: 14),
                    cursorColor: skyBlue,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      hintText: 'Sleep (ms)',
                      hintStyle: TextStyle(color: textSecondary.withOpacity(0.3)),
                      prefixIcon: Container(
                        padding: const EdgeInsets.all(14),
                        child: const Icon(Icons.timer, color: skyBlue, size: 18),
                      ),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 8),
          
          Row(
            children: [
              Icon(Icons.info_outline, color: skyBlue.withOpacity(0.5), size: 12),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'Jumlah: 1-1000 | Sleep: 100-60000 ms',
                  style: TextStyle(color: textSecondary.withOpacity(0.5), fontSize: 10, fontFamily: 'ShareTechMono'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSenderSelection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [navyMedium, navyLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: skyBlue.withOpacity(0.3), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: navyBlue.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.phone_android, color: Colors.white, size: 16),
              ),
              const SizedBox(width: 10),
              const Text(
                'SELECT SENDER',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.refresh, color: Colors.white70, size: 18),
                onPressed: _fetchSenders,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
            ],
          ),
          const SizedBox(height: 12),
          
          if (_isLoadingSenders)
            const Center(child: Padding(
              padding: EdgeInsets.all(16),
              child: CircularProgressIndicator(color: skyBlue, strokeWidth: 2),
            ))
          else if (_senders.isEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: navyDeep,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: warningOrange.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(Icons.warning, color: warningOrange, size: 16),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'No active senders found. Please add a sender first.',
                      style: TextStyle(color: textSecondary, fontSize: 12),
                    ),
                  ),
                ],
              ),
            )
          else
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _senders.map((sender) {
                final isSelected = _selectedSenderId == sender['id'];
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _selectedSenderId = isSelected ? null : sender['id'];
                    });
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      gradient: isSelected
                          ? LinearGradient(colors: [navyBlue, skyBlue], begin: Alignment.topLeft, end: Alignment.bottomRight)
                          : null,
                      color: isSelected ? null : navyDeep,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: isSelected ? skyBlue : skyBlue.withOpacity(0.3),
                        width: isSelected ? 1 : 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: successGreen,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          sender['sessionName'] ?? sender['nomor'] ?? 'Unknown',
                          style: TextStyle(
                            color: isSelected ? Colors.white : textSecondary,
                            fontSize: 12,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                        if (sender['type'] != null) ...[
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                            decoration: BoxDecoration(
                              color: skyBlue.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              sender['type'],
                              style: TextStyle(color: skyBlue, fontSize: 8),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }

  Widget _buildExecuteButton() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _pulseAnimation.value,
          child: Container(
            width: double.infinity,
            height: 56,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: _isExecuting ? [Colors.grey, Colors.grey.shade700] : [navyBlue, skyBlue],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(30),
              boxShadow: [
                BoxShadow(
                  color: skyBlue.withOpacity(0.3),
                  blurRadius: 15,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: _isExecuting ? null : _executeFunction,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                foregroundColor: Colors.white,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (_isExecuting)
                    const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  else
                    const Icon(Icons.play_arrow, size: 24),
                  const SizedBox(width: 10),
                  Text(
                    _isExecuting ? 'EXECUTING...' : 'EXECUTE FUNCTION',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildResults() {
    if (_executionResult == null) return const SizedBox.shrink();
    
    final isSuccess = _executionResult!['success'] == true;
    final results = _executionResult!['results'];
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [navyMedium, navyLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isSuccess ? successGreen.withOpacity(0.5) : errorRed.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: (isSuccess ? successGreen : errorRed).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  isSuccess ? Icons.check_circle : Icons.error,
                  color: isSuccess ? successGreen : errorRed,
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                isSuccess ? 'EXECUTION COMPLETED' : 'EXECUTION FAILED',
                style: TextStyle(
                  color: isSuccess ? successGreen : errorRed,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
          
          if (isSuccess && results != null) ...[
            const SizedBox(height: 16),
            
            Row(
              children: [
                _buildStatCard('SUCCESS', results['success'] ?? 0, successGreen),
                const SizedBox(width: 12),
                _buildStatCard('FAILED', results['failed'] ?? 0, errorRed),
              ],
            ),
            
            if (results['duration'] != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: navyDeep,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Icon(Icons.timer, color: skyBlue, size: 14),
                    const SizedBox(width: 8),
                    Text(
                      'Duration: ${results['duration']} seconds',
                      style: TextStyle(color: textSecondary, fontSize: 12, fontFamily: 'ShareTechMono'),
                    ),
                  ],
                ),
              ),
            ],
            
            if (results['logs'] != null && (results['logs'] as List).isNotEmpty) ...[
              const SizedBox(height: 16),
              const Text(
                'EXECUTION LOGS',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
              const SizedBox(height: 8),
              Container(
                constraints: const BoxConstraints(maxHeight: 200),
                decoration: BoxDecoration(
                  color: navyDeep,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: skyBlue.withOpacity(0.2)),
                ),
                child: ListView.builder(
                  padding: const EdgeInsets.all(8),
                  itemCount: (results['logs'] as List).length,
                  itemBuilder: (context, index) {
                    final log = (results['logs'] as List)[index];
                    Color logColor = textSecondary;
                    if (log.startsWith('[SUCCESS]')) logColor = successGreen;
                    else if (log.startsWith('[ERROR]') || log.startsWith('[FAILED]')) logColor = errorRed;
                    else if (log.startsWith('[WARN]')) logColor = warningOrange;
                    else if (log.startsWith('[send]') || log.startsWith('[relay]')) logColor = skyBlue;
                    
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Text(
                        log,
                        style: TextStyle(color: logColor, fontSize: 11, fontFamily: 'Monospace'),
                      ),
                    );
                  },
                ),
              ),
            ],
            
            if (results['errors'] != null && (results['errors'] as List).isNotEmpty) ...[
              const SizedBox(height: 16),
              const Text(
                'ERROR DETAILS',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
              const SizedBox(height: 8),
              ...(results['errors'] as List).map((err) => Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: errorRed.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: errorRed.withOpacity(0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Iteration ${err['iteration']}:',
                      style: TextStyle(color: errorRed, fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      err['message'],
                      style: TextStyle(color: errorRed.withOpacity(0.9), fontSize: 11, fontFamily: 'Monospace'),
                    ),
                  ],
                ),
              )),
            ],
          ],
          
          if (!isSuccess && _executionResult!['error'] != null) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: errorRed.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: errorRed.withOpacity(0.3)),
              ),
              child: Text(
                _executionResult!['error']['message'] ?? 'Unknown error',
                style: TextStyle(color: errorRed, fontSize: 12, fontFamily: 'Monospace'),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStatCard(String label, int value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: navyDeep,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Text(
              value.toString(),
              style: TextStyle(color: color, fontSize: 24, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(color: color.withOpacity(0.7), fontSize: 11, fontFamily: 'ShareTechMono'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _pulseController.dispose();
    _particleController.dispose();
    _pollingTimer?.cancel();
    _codeController.dispose();
    _targetController.dispose();
    _jumlahController.dispose();
    _sleepController.dispose();
    super.dispose();
  }
}

class GridPainter extends CustomPainter {
  final Color color;

  GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 0.5;

    for (double i = 0; i < size.width; i += 30) {
      canvas.drawLine(Offset(i, 0), Offset(i, size.height), paint);
    }
    for (double i = 0; i < size.height; i += 30) {
      canvas.drawLine(Offset(0, i), Offset(size.width, i), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}