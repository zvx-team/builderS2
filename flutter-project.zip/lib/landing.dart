import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'api_config.dart';
import 'login_page.dart';

class _C {
  static const bg = Color(0xFF0A0A0A);
  static const surface = Color(0xFF121212);
  static const card = Color(0xFF1C1C1C);
  static const logoBg = Color(0xFF242424);
  static const border = Color(0xFF2E2E2E);
  static const cyan = Color(0xFF5A5A5A);
  static const DarkGreyy = Color(0xFF707070);
  static const GreyYy = Color(0xFF8A8A8A);
  static const text = Color(0xFFE0E0E0);
  static const textGrey = Color(0xFF9E9E9E);
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _floatCtrl;
  late VideoPlayerController _videoController;

  @override
   void initState() {
     super.initState();
      _fadeCtrl = AnimationController(
       vsync: this,
       duration: const Duration(milliseconds: 800),
      );
      _fadeAnim = CurvedAnimation(parent:
      _fadeCtrl, curve: Curves.easeOutCubic);
      
      _floatCtrl = AnimationController(
       vsync: this,
       duration: const Duration(seconds: 3),
      )..repeat(reverse: true);
      
      WidgetsBinding.instance.addPostFrameCallback((_) {
       _fadeCtrl.forward();
     });
     
     _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
        _videoController.setVolume(1.0);
        _videoController.play();
       });
     }
     
     @override
     void dispose() {
       _fadeCtrl.dispose();
       _floatCtrl.dispose();
       _videoController.dispose();
       super.dispose();
    }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $uri');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.2,
            colors: [
              _C.surface,
              _C.bg,
              Color(0xFF0A0C10),
            ],
            stops: [0, 0.5, 1],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 24),
                  _buildLogoBox(),
                  const SizedBox(height: 32),
                  _buildBigTitle(),
                  const SizedBox(height: 28),
                  _buildDescCard(),
                  const SizedBox(height: 20),
                  _buildLoginButton(),
                  const SizedBox(height: 14),
                  _buildContactSupportButton(),
                  const SizedBox(height: 28),
                  _buildSocialSection(),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

 Widget _buildLogoBox() {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 24),
    child: AnimatedBuilder(
      animation: _floatCtrl,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, 5 * _floatCtrl.value),
          child: Container(
            width: double.infinity,
            height: 210,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  _C.logoBg.withOpacity(0.9),
                  _C.card.withOpacity(0.8),
                ],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: _C.cyan.withOpacity(0.2),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: _C.cyan.withOpacity(0.1),
                  blurRadius: 20,
                  spreadRadius: 2,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Stack(
              fit: StackFit.expand,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(28),
                  child: _videoController.value.isInitialized
                      ? AspectRatio(
                          aspectRatio: _videoController.value.aspectRatio,
                          child: VideoPlayer(_videoController),
                        )
                      : Container(color: Colors.black12),
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [
                        Colors.black.withOpacity(0.7),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}

  Widget _buildBigTitle() {
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [
              Color(0xFFFFFFFF), // putih di kiri
              Color(0xFF1DE9B6), // cyan di tengah-kanan
              Color(0xFFFFFFFF), // putih hint di ujung
            ],
            stops: [0.0, 0.6, 1.0],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: const Text(
            'XAVIERYZO V1.0',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 44,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
              letterSpacing: 4,
              height: 1.0,
            ),
          ),
        ),
        const SizedBox(height: 12),
        Container(
          width: 140,
          height: 2,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: const LinearGradient(
              colors: [Colors.transparent, _C.cyan, _C.DarkGreyy, Colors.transparent],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_C.cyan.withOpacity(0.1), _C.DarkGreyy.withOpacity(0.05)],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.cyan.withOpacity(0.2)),
          ),
          child: const Text(
            'New • Version • Colaboration',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _C.cyan,
              fontSize: 11,
              letterSpacing: 2,
              fontWeight: FontWeight.w600,
              fontFamily: 'Orbitron',
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDescCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              _C.card.withOpacity(0.7),
              _C.card.withOpacity(0.5),
            ],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: _C.cyan.withOpacity(0.2),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: _C.cyan.withOpacity(0.08),
              blurRadius: 15,
              spreadRadius: 1,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_C.GreyYy.withOpacity(0.6), _C.cyan.withOpacity(0.3)],
                ),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: _C.cyan.withOpacity(0.5), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: _C.cyan.withOpacity(0.3),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: const Center(
                child: Icon(
                  Icons.shield_outlined,
                  color: _C.cyan,
                  size: 30,
                ),
              ),
            ),
            const SizedBox(height: 20),
            ShaderMask(
              shaderCallback: (bounds) => const LinearGradient(
                colors: [Color(0xFF1DE9B6), Color(0xFF00C9A0)],
              ).createShader(bounds),
              child: const Text(
                'XAVIERYZO BUGGERS',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'New Apps Bugs By @RixzzNotDev, Already using the latest function, and this application was created by the Xavieryzo team',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _C.textGrey,
                fontSize: 13,
                height: 1.6,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoginButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              _C.cyan.withOpacity(0.15),
              _C.DarkGreyy.withOpacity(0.1),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.cyan, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: _C.cyan.withOpacity(0.2),
              blurRadius: 10,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => LoginPage()),
            ),
            borderRadius: BorderRadius.circular(16),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.rocket_launch_rounded, color: _C.cyan, size: 20),
                  SizedBox(width: 12),
                  Text(
                    'LOGIN',
                    style: TextStyle(
                      color: _C.cyan,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContactSupportButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          color: _C.card.withOpacity(0.5),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.border, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 8,
              spreadRadius: 0,
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => _openUrl('https://t.me/RixzzNotDev'),
            borderRadius: BorderRadius.circular(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.headset_mic_rounded, color: _C.textGrey, size: 20),
                const SizedBox(width: 12),
                Text(
                  'INFORMASI CONTACT',
                  style: TextStyle(
                    color: _C.textGrey,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSocialSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              _C.card.withOpacity(0.6),
              _C.card.withOpacity(0.4),
            ],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: _C.border, width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 12,
              spreadRadius: 2,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: _C.cyan.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _C.cyan.withOpacity(0.2)),
              ),
              child: Text(
                'HUBUNGI KAMI',
                style: TextStyle(
                  color: _C.cyan,
                  fontSize: 11,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 24),
            Row(
  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
  children: [
    _buildSocialItem(
      icon: FontAwesomeIcons.telegram,
      bgColor: Color(0xFF29B6F6),
      label: 'Telegram',
      onTap: () => _openUrl('https://t.me/RixzzNotDev'),
    ),
    _buildSocialItem(
      icon: FontAwesomeIcons.tiktok,
      bgColor: Color(0xFF6B7280),
      label: 'TikTok',
      onTap: () => _openUrl('https://tiktok.com/@rixzzoffc'),
    ),
  ],
),
          ],
        ),
      ),
    );
  }

  Widget _buildSocialItem({
  required IconData icon,
  required Color bgColor,
  required String label,
  required VoidCallback onTap,
}) {
  return GestureDetector(
    onTap: onTap,
    child: Column(
      children: [
        Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: bgColor.withOpacity(0.15),
            border: Border.all(color: bgColor.withOpacity(0.8), width: 2),
            boxShadow: [
              BoxShadow(
                color: bgColor.withOpacity(0.35),
                blurRadius: 14,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Center(
            child: FaIcon(icon, color: bgColor, size: 26),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          label,
          style: TextStyle(
            color: _C.textGrey,
            fontSize: 11,
            fontWeight: FontWeight.w500,
            letterSpacing: 1,
          ),
        ),
      ],
    ),
  );
 }
}